#!/bin/bash
# Line to be addedd to the Linux CRON
rm -rf /opt/imzabbix/log/probeim.log.*


