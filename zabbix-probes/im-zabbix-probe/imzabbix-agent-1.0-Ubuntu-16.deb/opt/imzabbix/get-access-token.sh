#!/bin/bash

IAM_USER='__YOUR_IAM_USER__'
IAM_PASSWORD='__YOUR_IAM_PASSWORD__'
IAM_CLIENT_SECRET='__YOUR_CLIENT_SECRET__'
IAM_CLIENT_ID='__YOUR_CLIENT_ID__'

result=$(curl -s -L \
  -d grant_type=password \
  -d client_id=${IAM_CLIENT_ID} \
  -d client_secret=${IAM_CLIENT_SECRET} \
  -d username=${IAM_USER} \
  -d password=${IAM_PASSWORD} \
  ${IAM_ENDPOINT:-https://iam-test.indigo-datacloud.eu/token})

if [[ $? != 0 ]]; then
  echo "Error!"
  echo $?
  echo $result
  exit 1
fi

echo $result

#access_token=$(echo $result | jq -r .access_token)


