#!/bin/bash
# Line to be addedd to the Linux CRON
rm -f /opt/imzabbix/log/probeim.log.*
