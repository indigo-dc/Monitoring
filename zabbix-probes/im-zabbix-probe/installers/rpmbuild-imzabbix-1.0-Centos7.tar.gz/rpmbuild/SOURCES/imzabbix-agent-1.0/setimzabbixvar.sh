#!/bin/bash
CLIENT_ID=__CLIENT_ID__
CLIENT_SECRET=__CLIENT_SECRET__
TOKEN=__IAM_TOKEN__
REFRESH=__REFRESH_TOKEN__
ZABBIX_SERVER=__ZABBIX_SERVER_IP__
ZABBIX_API_URL=http://__ZABBIX_WEB_IP__/api_jsonrpc.php
clear
echo Ejecutar probe IM
python probeim.py -i $CLIENT_ID -s $CLIENT_SECRET -t $TOKEN -r $REFRESH -u Admin -p zabbix -v $ZABBIX_SERVER -a $ZABBIX_API_URL
