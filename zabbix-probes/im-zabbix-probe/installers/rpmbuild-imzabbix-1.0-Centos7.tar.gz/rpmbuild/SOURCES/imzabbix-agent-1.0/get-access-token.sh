#!/bin/bash

IAM_USER='__IAM_USER__'
IAM_PASSWORD='__IAM_PASSWORD__'


if [[ -z ${IAM_USER} ]]; then
  read -p "Username: " IAM_USER
fi

#echo -ne "Password:"
#read -s IAM_PASSWORD
echo

result=$(curl -s -L \
  -d grant_type=password \
  -d client_id=__CLIENT_ID__ \
  -d client_secret=__CLIENT_SECRET__ \
  -d username=${IAM_USER} \
  -d password=${IAM_PASSWORD} \
  ${IAM_ENDPOINT:-https://iam-test.indigo-datacloud.eu/token})

if [[ $? != 0 ]]; then
  echo "Error!"
  echo $?
  echo $result
  exit 1
fi

echo $result

access_token=$(echo $result | jq -r .access_token)

#echo "export IAM_ACCESS_TOKEN=\"${access_token}\""
