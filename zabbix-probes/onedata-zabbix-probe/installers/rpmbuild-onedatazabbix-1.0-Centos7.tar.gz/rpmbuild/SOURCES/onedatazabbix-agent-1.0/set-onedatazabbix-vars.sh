#!/bin/bash
CLIENT_ID=__YOUR_APP_CLIENT_ID__
CLIENT_SECRET=__YOUR_APP_CLIENT_SECRET__
ONEDATA_TOKEN=__IAM_TOKEN_OBTAINED__
REFRESH=__IAM_APP_REFRESH_TOKEN__
ZABBIX_URL=http://__IP_ZABBIX_WEB__/api_jsonrpc.php
ZABBIX_SERVER=__IP_ZABBIX_SERVER__
clear
# the next commandline assumes "Admin" as Zabbix username and "zabbix" as Zabbix password (-u and -p options)
echo Launching probe: ONEDATA
python onedata_zabbix_agent.py -u=Admin -p=zabbix -t=$ONEDATA_TOKEN -i $CLIENT_ID -s $CLIENT_SECRET -r $REFRESH -a $ZABBIX_URL -v $ZABBIX_SERVER
