#!/bin/bash
# Line to be addedd to the Linux CRON
rm -rf /opt/onedatazabbix/log/od-zbx-agent.log.*


